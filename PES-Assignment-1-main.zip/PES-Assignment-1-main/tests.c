/**
* @file tests.c
* @brief All the unit test implementations for PES assignment 1
*
*
* @author Stanley A Young
* @date 27 August 2021
* @version 1.0
*
*/

#include "tests.h"
#include "functions.h"

#define SIZE 35

char buffer[SIZE];


int test_uint_to_binstr() {
    uint32_t num = 1;
    uint8_t nbits = 0;
    size_t size = SIZE;
    char* str = buffer;

    int ret = 0;
    int expect = -1;
    uint8_t errors = 0;
    

    // 0. Check illegal nbits (0)
    ret = uint_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x01;


    // 1. Check illegal nbits (>32)
    nbits = 33;

    ret = uint_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x02;


    // 2. Check number too large
    nbits = 4;
    num = 310;

    ret = uint_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x04;

    // 3. Check expected output (10)
    nbits = 8;
    num = 18;
    expect = 10;

    ret = uint_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x08;

    // 4. Check expected output (18)
    nbits = 16;
    num = 65400;
    expect = 18;

    ret = uint_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x10;


    // 5. Check expected output (3)
    nbits = 2;
    num = 3;
    expect = 4;

    ret = uint_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x20;


    return errors > 0 ? 0 : 1;
}


int test_int_to_binstr() {
    int32_t num = 1;
    uint8_t nbits = 0;
    size_t size = SIZE;
    char* str = buffer;

    int ret = 0;
    int expect = -1;
    uint8_t errors = 0;
    

    // 0. Check illegal nbits (0)
    ret = int_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x01;


    // 1. Check illegal nbits (>32)
    nbits = 33;

    ret = int_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x02;


    // 2. Check number too large
    nbits = 4;
    num = 310;

    ret = int_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x04;


    // 3. Check expected output (10)
    nbits = 8;
    num = 18;
    expect = 10;

    ret = int_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x08;


    // 4. Check expected output (34)
    nbits = 32;
    num = 65400;
    expect = 34;

    ret = int_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x10;
    

    // 5. Check expected output (6)
    nbits = 4;
    num = -1;
    expect = 6;

    ret = int_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x20;


    // 6. Check expected output (10)
    nbits = 8;
    num = -3;
    expect = 10;

    ret = int_to_binstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x40;


    return errors > 0 ? 0 : 1;
}


int test_uint_to_hexstr() {
    int32_t num = 1;
    uint8_t nbits = 0;
    size_t size = SIZE;
    char* str = buffer;

    int ret = 0;
    int expect = -1;
    uint8_t errors = 0;

    // 0. Check illegal nbits (0)
    ret = uint_to_hexstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x01;


    // 1. Check illegal nbits (>32)
    nbits = 33;

    ret = uint_to_hexstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x02;
    

    // 2. Check illegal nbits (not in [4, 8, 16, 32])
    nbits = 3;

    ret = uint_to_hexstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x04;

 
    // 3. Check number too large
    nbits = 4;
    num = 310;

    ret = uint_to_hexstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x08;


    // 4. Check expected output (18 nbits = 8)
    nbits = 8;
    num = 18;
    expect = 4;

    ret = uint_to_hexstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x10;


    // 5. Check expected output (18 nbits = 16)
    nbits = 16;
    num = 18;
    expect = 6;

    ret = uint_to_hexstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x20;


    // 6. Check expected output (65400)
    nbits = 16;
    num = 65400;
    expect = 6;

    ret = uint_to_hexstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x40;


    // 7. Check expected output (310)
    nbits = 16;
    num = 310;
    expect = 6;

    ret = uint_to_hexstr(str, size, num, nbits);
    if(ret != expect) errors |= 0x80;

    
    return errors > 0 ? 0 : 1;
}


int test_twiggle_bit() {
    uint32_t in = 0x12345678;
    int bit = -1;
    operation_t op = CLEAR;

    uint32_t ret = 0;
    uint32_t exp = 0xFFFFFFFF;
    uint8_t errors = 0;


    // 0. Test bit out of bounds (bit < 0)
    ret = twiggle_bit(in, bit, op);
    if(ret != exp) errors |= 0x01;   
    

    // 1. Test bit out of bounds (bit > 31)
    bit = 33;
    ret = twiggle_bit(in, bit, op);
    if(ret != exp) errors |= 0x02;


    // 2. Test clear
    bit = 3;
    exp = 0x12345670;
    ret = twiggle_bit(in, bit, op);
    if(ret != exp) errors |= 0x04;


    // 3. Test set
    op = SET;
    exp = 0x12345678;
    ret = twiggle_bit(in, bit, op);
    if(ret != exp) errors |= 0x08;


    // 4. Test toggle
    op = TOGGLE;
    exp = 0x12345670;
    ret = twiggle_bit(in, bit, op);
    if(ret != exp) errors |= 0x10;


    // 5. Test toggle
    in = 0x7337;
    exp = 0x7317;
    bit = 5;
    ret = twiggle_bit(in, bit, op);
    if(ret != exp) errors |= 0x20;


    return errors > 0 ? 0 : 1;

}


int test_grab_three_bits() {
    uint32_t in = 0x7337;
    int bit = -1;

    uint32_t ret = 0;
    uint32_t exp = 0xFFFFFFFF;
    uint8_t errors = 0;


    // 0. Test bit out of bounds (bit < 0)
    ret = grab_three_bits(in, bit);
    if(ret != exp) errors |= 0x01;   
    

    // 1. Test bit out of bounds (bit > 31)
    bit = 33;
    ret = grab_three_bits(in, bit);
    if(ret != exp) errors |= 0x02;


    // 2. Check expected output (bit = 6)
    bit = 6;
    exp = 4;

    ret = grab_three_bits(in, bit);
    if(ret != exp) errors |= 0x04;


    // 3. Check expected output (bit = 7)
    bit = 7;
    exp = 6;

    ret = grab_three_bits(in, bit);
    if(ret != exp) errors |= 0x08;


    // 4. Check near boundary (bit = 31)
    in = 0xFFFFFFFF;
    bit = 31;
    exp = 1;

    ret = grab_three_bits(in, bit);
    if(ret != exp) errors |= 0x10;
    

    // 5. Check near boundary (bit = 30)
    in = 0xFFFFFFFF;
    bit = 30;
    exp = 3;

    ret = grab_three_bits(in, bit);
    if(ret != exp) errors |= 0x20;
    

    // 6. Check near boundary (bit = 29)
    in = 0xFFFFFFFF;
    bit = 29;
    exp = 7;

    ret = grab_three_bits(in, bit);
    if(ret != exp) errors |= 0x40;


    return errors > 0 ? 0 : 1;
}


int test_hexdump() {
    char buf[5] = "test\0";
    char teststr[20];
    char* ret;

    uint32_t errors = 0;


    // 0. str not large enough
    ret = hexdump(teststr, 20, buf, 5);
    if((int) sizeof(ret) != 8) errors |= 0x01;


    // 1. Match output
    char str[1024];
    ret = hexdump(str, sizeof(str), buf, 5);

    printf("\n\nTesting hexdump");
    printf("\nInput: \"test\"");
    printf("\nOutput: ");
      
    for(int i = 0; i < 24; ++i) { 
        // print the string
        printf("%c", ret[i]);
    }


    // 2. Match output multiline
    char buf2[22] = "This is a test string";
    ret = hexdump(str, sizeof(str), buf2, 22);

    printf("\n\nTesting hexdump");
    printf("\nInput: \"This is a test string\"");
    printf("\nOutput:\n");
      
    for(int i = 0; i < 16 + 21*3; ++i) { 
        // print the string
        printf("%c", ret[i]);
    }


    printf("\n");


    return errors > 0 ? 0 : 1;
}