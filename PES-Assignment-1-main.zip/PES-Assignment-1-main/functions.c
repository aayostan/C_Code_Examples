/**
* @file functions.c
* @brief All the function implementations for PES assignment 1
*
*
* @author Stanley A Young
* @date 27 August 2021
* @version 1.0
*
*/

#include "functions.h"

int uint_to_binstr(char *str, size_t size, uint32_t num, uint8_t nbits) {
    // Pre-operations error checking
    if(nbits <= 0 || nbits > 32) return -1;

    // Conversion Algorithm
    int bitcount = 0;
    uint32_t val = num;
    uint8_t rem = 0;
    
    while(val > 0) {
        bitcount++;
        
        // Mid- operations error checking
        if(bitcount > nbits) return -1;

        rem = val % 2;
        str[nbits + 2 - bitcount] = rem ? '1' : '0'; 
        val /= 2;
    }

    // Fill in remaining 0's
    while(bitcount < nbits) {
        bitcount++;
        str[nbits + 2 - bitcount] = '0';
    }

    str[0] = '0';
    str[1] = 'b';
    bitcount += 2;

    str[nbits + 2] = '\0';

    return bitcount;
}


int int_to_binstr(char *str, size_t size, int32_t num, uint8_t nbits) {
    // Pre-operations error checking
    if(nbits <= 0 || nbits > 32) return -1;

    // Conversion Algorithm
    int bitcount = 0;
    uint32_t val = (num < 0) ? -num : num;
    bitcount = uint_to_binstr(str, size, val, nbits);
    
    // Mid-operations error checking
    if(bitcount == -1) return -1;

    if(num < 0) {
        // 2's complement
        for(int i = 2; i < bitcount; ++i) {
            // Invert
            str[i] = (str[i] == '1') ? '0' : '1';
        }
        for(int i = bitcount - 1; i >= 2; --i) {
            // Add 1
            if(str[i] == '0') {
                str[i] = '1';
                break;
            } else {
                str[i] = '0';
            }
        }
    }

    return bitcount;
}


int uint_to_hexstr(char *str, size_t size, uint32_t num, uint8_t nbits) {
    // Preprocessing error checking
    if(nbits != 4 && nbits != 8 && nbits != 16 && nbits != 32) {
        return -1;
    }

    // Conversion Algorithm
        /* I could have converted to binary then to hex using
            previous functions, but that would still require 
            further processing, so I decided to do it directly
        */
    int pos = (nbits / 4) + 2;
    int bitcount = 0;
    uint32_t val = num;
    uint8_t rem = 0;
    
    str[pos] = '\0';

    while(val > 0) {
        bitcount += 4;
        pos--;
        
        // Mid- operations error checking
        if(bitcount > nbits) return -1;

        // Might look better as an array...
        rem = val % 16;
        switch(rem) {
            case 0:
                str[pos] = '0';
                break;
            case 1:
                str[pos] = '1';
                break;
            case 2:
                str[pos] = '2';
                break;
            case 3:
                str[pos] = '3';
                break;
            case 4:
                str[pos] = '4';
                break;
            case 5:
                str[pos] = '5';
                break;
            case 6:
                str[pos] = '6';
                break;
            case 7:
                str[pos] = '7';
                break;
            case 8:
                str[pos] = '8';
                break;
            case 9:
                str[pos] = '9';
                break;
            case 10:
                str[pos] = 'A';
                break;
            case 11:
                str[pos] = 'B';
                break;
            case 12:
                str[pos] = 'C';
                break;
            case 13:
                str[pos] = 'D';
                break;
            case 14:
                str[pos] = 'E';
                break;
            case 15:
                str[pos] = 'F';
                break;
            default:
                return -1;
                break;

        }

        val /= 16;

    }

    // Fill in remaining 0's
    while(bitcount < nbits) {
        bitcount += 4;
        str[--pos] = '0';
    }

    str[0] = '0';
    str[1] = 'x';

    return (bitcount / 4) + 2;
}


uint32_t twiggle_bit(uint32_t input, int bit, operation_t operation) {
    if(bit < 0 || bit >= 32) return -1;

    switch(operation) {
        case CLEAR:
            input &= ~(1 << bit);
            break;
        case SET:
            input |= (1 << bit);
            break;
        case TOGGLE:
            input ^= (1 << bit);
            break;
        default:
            return -1;
    }

    return input;
}


uint32_t grab_three_bits(uint32_t input, int start_bit) {
    if(start_bit < 0 || start_bit >= 32) return -1;

    uint32_t mask = 0x7 << start_bit;

    input &= mask;
    input >>= start_bit;

    return input;
}


char *hexdump(char *str, size_t size, const void *loc, size_t nbytes) {
    /* for each byte there needs to be room in the string
        for a space and two characters, that is each
        byte requires three spots, and for every 16
        bytes there needs to be an extra 8 spots.
    */
    int reqsize = (((nbytes / 16) + 1) * 8) + (nbytes * 3);

    if(reqsize > size) {
        str[0] = '\0';
        return '\0';
    }

    int stritt = 0;
    int locitt = 0;
    
    char begin[8];
    char singl[5];
    // Writes out the offset
    uint_to_hexstr(begin, sizeof(begin), locitt, 16);
    for(int i = 0; i < sizeof(begin); ++i) {
        str[stritt++] = begin[i];
    }
    
    str[stritt++] = ' ';
    str[stritt++] = ' ';  

    char * currc = (char *) loc;
    while(currc[locitt] != '\0') {
        int curri = (int) currc[locitt++];
        
        uint_to_hexstr(singl, sizeof(singl), curri, 8);

        for(int i = 2; i <= 3; ++i) {
            str[stritt++] = singl[i];
        }

        int rem = locitt % 16;
        if(rem == 0) {
            str[stritt++] = '\n';
            uint_to_hexstr(begin, sizeof(begin), locitt, 16);
            for(int i = 0; i < sizeof(begin); ++i) {
                str[stritt++] = begin[i];
            }
            str[stritt++] = ' ';
        }
        str[stritt++] = ' ';
    }
    str[stritt++] = '\0';

    return str;
}
