# PES-Assignment-1
Code for Assignment 1 for PES, ECEN-5813, Fall 2021

I built this code using the gcc compiler with the following line:
gcc functions.c tests.c main.c -Wall -Werror

I did not receive any errors. I am using windows currently, so I ran the program by calling the a.exe file in the command prompt
