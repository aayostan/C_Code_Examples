/**
* @file functions.h
* @brief All the function declarations for PES assignment 1
*
*
* @author Stanley A Young
* @date 27 August 2021
* @version 1.0
*
*/

#ifndef __FUNCTIONS_H__
#define __FUNCTIONS_H__
#include <stdint.h>

/**
* @brief Convert an unsigned integer to a string of binary digits
*
* @param str Pointer to an empty string
* @param size size of the string in bytes
* @param num the unsigned integer to convert
* @param nbits the number of bits to convert to
*
* @return if operations is successful number of characters written to str 
*           not including the terminating null character
*           otherwise returns -1 on an error
*/
int uint_to_binstr(char *str, size_t size, uint32_t num, uint8_t nbits);


/**
* @brief Convert a signed integer to a string of binary digits
*
* @param str Pointer to an empty string
* @param size size of the string in bytes
* @param num the unsigned integer to convert
* @param nbits the number of bits to convert to
*
* @return if operations is successful number of characters written to str 
*           not including the terminating null character
*           otherwise returns -1 on an error
*/
int int_to_binstr(char *str, size_t size, int32_t num, uint8_t nbits);


/**
* @brief Convert an unsigned integer to a string of binary digits
*
* @param str Pointer to an empty string
* @param size size of the string in bytes
* @param num the unsigned integer to convert
* @param nbits the number of bits to convert to (must be 4, 8 ,16, or 32)
*
* @return if operations is successful number of characters written to str 
*           not including the terminating null character
*           otherwise returns -1 on an error
*/
int uint_to_hexstr(char *str, size_t size, uint32_t num, uint8_t nbits);


/**
* @brief 
*
* @param input 32-bit number
* @param bit bit position 
*               between 0 and 31 inclusive
* @param operation what to do with the bit
*
* @return returns the input having operation done on it
*           unless there is an error in which case returns 0xFFFFFFFF
*
*/
typedef enum {
    CLEAR,
    SET,
    TOGGLE
} operation_t;
uint32_t twiggle_bit(uint32_t input, int bit, operation_t operation);


/**
* @brief Returns three bits from the input value shifted down.
*
* @param input the input value
* @param start_bit the least significant bit position to start at (0-31)
*
* @return returns the three bits shifted down unless there is an error
*           in which case it just returns -1 (0xFFFFFFFF)
*
*/
uint32_t grab_three_bits(uint32_t input, int start_bit);


/**
* @brief Returns a string representing a "dump" of memory
*           16 bytes per line
*
* @param str Pointer to an empty string
* @param size size of the string in bytes
* @param loc starting location in memory
* @param nbytes 
*
* @return pointer to the resultant dump,
*           empty if there is an error
*
*/
char *hexdump(char *str, size_t size, const void *loc, size_t nbytes);
#endif /* __FUNCTIONS_H__ */