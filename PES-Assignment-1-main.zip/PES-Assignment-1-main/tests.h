/**
* @file tests.h
* @brief All the unit tests for the functions for PES assignment 1
*
*
* @author Stanley A Young
* @date 27 August 2021
* @version 1.0
*
*/

#ifndef __TESTS_H__
#define __TESTS_H__
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

/**
* @brief Tests the uint_to_binstr function
*   The variable errors can be printed to
*   identify which test numbers failed.
*   The bit positions that are asserted
*   indicate the tests that failed.
* 
* @return 1 if success. 0 if failure;
*/
int test_uint_to_binstr();

/**
* @brief Tests the int_to_binstr function
*   The variable errors can be printed to
*   identify which test numbers failed.
*   The bit positions that are asserted
*   indicate the tests that failed.
* 
* @return 1 if success. 0 if failure;
*/
int test_int_to_binstr();

/**
* @brief Tests the uint_to_hexstr function
*   The variable errors can be printed to
*   identify which test numbers failed.
*   The bit positions that are asserted
*   indicate the tests that failed.
* 
* @return 1 if success. 0 if failure;
*/
int test_uint_to_hexstr();

/**
* @brief Tests the twiggle_bit function
*   The variable errors can be printed to
*   identify which test numbers failed.
*   The bit positions that are asserted
*   indicate the tests that failed.
* 
* @return 1 if success. 0 if failure;
*/
int test_twiggle_bit();

/**
* @brief Tests the grab_three_bits function
*   The variable errors can be printed to
*   identify which test numbers failed.
*   The bit positions that are asserted
*   indicate the tests that failed.
* 
* @return 1 if success. 0 if failure;
*/
int test_grab_three_bits();

/**
* @brief Tests the hexdump function
*   The variable errors can be printed to
*   identify which test numbers failed.
*   The bit positions that are asserted
*   indicate the tests that failed.
* 
* @return 1 if success. 0 if failure;
*/
int test_hexdump();

#endif /* __TESTS_H__ */