/**
* @file main.h
* @brief All includes for the main file for the program
*
*
* @author Stanley A Young
* @date 27 August 2021
* @version 1.0
*
*/

#ifndef __MAIN_H__
#define __MAIN_H__
#include "functions.h"
#include "tests.h"
#include <stdio.h>

#endif /* __MAIN_H__ */