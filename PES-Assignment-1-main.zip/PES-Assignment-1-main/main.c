/**
* @file main.c
* @brief main file for for PES assignment 1
*           runs all the test functions.
*
* @author Stanley A Young
* @date 31 August 2021
* @version 1.0
*
*/

#include "main.h"

int main() {
    uint8_t ret = 0;
    printf("Hello World!");
    ret = test_uint_to_binstr();
    printf("\nTesting uint_to_binstr: %x", ret);
    ret = test_int_to_binstr();
    printf("\nTesting int_to_binstr: %x", ret);
    ret = test_uint_to_hexstr();
    printf("\nTesting uint_to_hexstr: %x", ret);
    ret = test_twiggle_bit();
    printf("\nTesting twiggle_bit: %x", ret);
    ret = test_grab_three_bits();
    printf("\nTesting grab_three_bits: %x", ret);
    ret = test_hexdump();
    printf("\nTesting hexdump: %x", ret);


    return 0;
}